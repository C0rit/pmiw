let opart;
let cant = 133.3;
let mod = 133.3;

function preload(){
  opart = loadImage ("opart.jpeg");
  
  
}
function setup() {
  createCanvas(800, 400);
}

function draw() {
  fill(0);
  rect(400,0,800,400);
  image (opart, 0, 0, 400, 400);
  
  
  for (let x = 0; x < 800; x++){
    for (let y = 0; y < 400; y++){
     cuadrados (x, y, cant);
      circulos (x, y, cant / 3);
      
    }
  }
}

//intento

function cuadrados(x, y, t) {
  rectMode(CENTER); // El centro como punto de partida
  let xmod = x * mod;
  let ymod = y * mod;

  if ((x + y) % 2 === 0) {
    fill(keyIsPressed ? color(7, 15, 31) : color(33, 52, 170));
  } else {
    fill(keyIsPressed ? color(33, 52, 170) : color(7, 15, 31));
  }

  rect(xmod + 467, ymod + 67, t, t);
}

function circulos(x, y, t) {
  let xmod = x * mod;
  let ymod = y * mod;

  if ((x + y) % 2 === 0) {
    fill(keyIsPressed ? color(33, 52, 170) : color(7, 15, 31));
  } else {
    fill(keyIsPressed ? color(7, 15, 31) : color(33, 52, 170));
  }

  if (sobreObra()) {
    let d = dist(mouseX, mouseY, xmod + 467, ymod + 67);
    let tam = map(d, 0, 565, mod / 2, mod * 2 - 100);
    circle(xmod + 467, ymod + 67, tam);
  } else {
    circle(xmod + 467, ymod + 67, t * 3);
  }
}

function sobreObra() {
  return mouseX > width / 2;
}